"""
VideoPlayerBot, Telegram Video Chat Bot
Copyright (c) 2021  Asm Safone <https://github.com/AsmSafone>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>
"""

import os
import re
import sys
import time
import ffmpeg
import asyncio
import subprocess
from asyncio import sleep
from plugins.nopm import User
from youtube_dl import YoutubeDL
from pyrogram import Client, filters
from pyrogram.types import Message
from pytgcalls import GroupCallFactory
from helpers.bot_utils import USERNAME
from config import AUDIO_CALL, VIDEO_CALL
from youtubesearchpython import VideosSearch
from helpers.decorators import authorized_users_only
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery


ydl_opts = {
        "quiet": True,
        "geo_bypass": True,
        "nocheckcertificate": True,
}
ydl = YoutubeDL(ydl_opts)
group_call = GroupCallFactory(User, GroupCallFactory.MTPROTO_CLIENT_TYPE.PYROGRAM).get_group_call()


@Client.on_callback_query(filters.regex("pause_callback"))
async def pause_callbacc(client, CallbackQuery):
    chat_id = CallbackQuery.message.chat.id
    if chat_id in AUDIO_CALL:
        text = f"⏸ 𝗣𝗮𝘂𝘀𝗲𝗱 !"
        await AUDIO_CALL[chat_id].set_audio_pause(True)
    elif chat_id in VIDEO_CALL:
        text = f"⏸ 𝗣𝗮𝘂𝘀𝗲𝗱 !"
        await VIDEO_CALL[chat_id].set_video_pause(True)
    else:
        text = f"❌ 𝗡𝗼𝘁𝗵𝗶𝗻𝗴 𝗶𝘀 𝗣𝗹𝗮𝘆𝗶𝗻𝗴 !"
    await Client.answer_callback_query(
        CallbackQuery.id, text, show_alert=True
    )

@Client.on_callback_query(filters.regex("resume_callback"))
async def resume_callbacc(client, CallbackQuery):
    chat_id = CallbackQuery.message.chat.id
    if chat_id in AUDIO_CALL:
        text = f"▶️ 𝗥𝗲𝘀𝘂𝗺𝗲𝗱 !"
        await AUDIO_CALL[chat_id].set_audio_pause(False)
    elif chat_id in VIDEO_CALL:
        text = f"▶️ 𝗥𝗲𝘀𝘂𝗺𝗲𝗱 !"
        await VIDEO_CALL[chat_id].set_video_pause(False)
    else:
        text = f"❌ 𝗡𝗼𝘁𝗵𝗶𝗻𝗴 𝗶𝘀 𝗣𝗹𝗮𝘆𝗶𝗻𝗴 !"
    await Client.answer_callback_query(
        CallbackQuery.id, text, show_alert=True
    )


@Client.on_callback_query(filters.regex("end_callback"))
async def end_callbacc(client, CallbackQuery):
    chat_id = CallbackQuery.message.chat.id
    if chat_id in AUDIO_CALL:
        text = f"⏹️ 𝗦𝘁𝗼𝗽𝗽𝗲𝗱 !"
        await AUDIO_CALL[chat_id].stop()
        AUDIO_CALL.pop(chat_id)
    elif chat_id in VIDEO_CALL:
        text = f"⏹️ 𝗦𝘁𝗼𝗽𝗽𝗲𝗱 !"
        await VIDEO_CALL[chat_id].stop()
        VIDEO_CALL.pop(chat_id)
    else:
        text = f"❌ 𝗡𝗼𝘁𝗵𝗶𝗻𝗴 𝗶𝘀 𝗣𝗹𝗮𝘆𝗶𝗻𝗴 !"
    await Client.answer_callback_query(
        CallbackQuery.id, text, show_alert=True
    )
    await Client.send_message(
        chat_id=CallbackQuery.message.chat.id,
        text=f"✅ 𝗦𝘁𝗿𝗲𝗮𝗺𝗶𝗻𝗴 𝗦𝘁𝗼𝗽𝗽𝗲𝗱 𝗔𝗻𝗱 𝗟𝗲𝗳𝘁 𝗧𝗵𝗲 𝗩𝗶𝗱𝗲𝗼 𝗖𝗵𝗮𝘁 !"
    )
    await CallbackQuery.message.delete()


@Client.on_message(filters.command(["stream", f"stream@{USERNAME}"]) & filters.group & ~filters.edited)
@authorized_users_only
async def stream(client, m: Message):
    msg = await m.reply_text("🔄 𝗣𝗿𝗼𝗰𝗲𝘀𝘀𝗶𝗻𝗴...")
    chat_id = m.chat.id
    media = m.reply_to_message
    if not media and not ' ' in m.text:
        await msg.edit("❗𝗦𝗲𝗻𝗱 𝗠𝗲 𝗔𝗻 𝗟𝗶𝘃𝗲 𝗦𝘁𝗿𝗲𝗮𝗺 𝗟𝗶𝗻𝗸 / 𝗬𝗼𝘂𝘁𝘂𝗯𝗲 𝗩𝗶𝗱𝗲𝗼 𝗟𝗶𝗻𝗸 / 𝗥𝗲𝗽𝗹𝘆 𝗧𝗼 𝗔𝗻 𝗩𝗶𝗱𝗲𝗼 𝗧𝗼 𝗦𝘁𝗮𝗿𝘁 𝗩𝗶𝗱𝗲𝗼 𝗦𝘁𝗿𝗲𝗮𝗺𝗶𝗻𝗴 !")

    elif ' ' in m.text:
        text = m.text.split(' ', 1)
        query = text[1]
        if not 'http' in query:
            return await msg.edit("❗𝗦𝗲𝗻𝗱 𝗠𝗲 𝗔𝗻 𝗟𝗶𝘃𝗲 𝗦𝘁𝗿𝗲𝗮𝗺 𝗟𝗶𝗻𝗸 / 𝗬𝗼𝘂𝘁𝘂𝗯𝗲 𝗩𝗶𝗱𝗲𝗼 𝗟𝗶𝗻𝗸 / 𝗥𝗲𝗽𝗹𝘆 𝗧𝗼 𝗔𝗻 𝗩𝗶𝗱𝗲𝗼 𝗧𝗼 𝗦𝘁𝗮𝗿𝘁 𝗩𝗶𝗱𝗲𝗼 𝗦𝘁𝗿𝗲𝗮𝗺𝗶𝗻𝗴 !")
        regex = r"^(https?\:\/\/)?(www\.youtube\.com|youtu\.?be)\/.+"
        match = re.match(regex, query)
        if match:
            await msg.edit("🔄 𝗦𝘁𝗮𝗿𝘁𝗶𝗻𝗴 𝗬𝗼𝘂𝘁𝘂𝗯𝗲 𝗩𝗶𝗱𝗲𝗼 𝗦𝘁𝗿𝗲𝗮𝗺...")
            try:
                meta = ydl.extract_info(query, download=False)
                formats = meta.get('formats', [meta])
                for f in formats:
                    ytstreamlink = f['url']
                link = ytstreamlink
                search = VideosSearch(query, limit=1)
                opp = search.result()["result"]
                oppp = opp[0]
                thumbid = oppp["thumbnails"][0]["url"]
                split = thumbid.split("?")
                thumb = split[0].strip()
            except Exception as e:
                return await msg.edit(f"❌ 𝗬𝗼𝘂𝘁𝘂𝗯𝗲 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱 𝗘𝗿𝗿𝗼𝗿 ! \n\n{e}")
                print(e)

        else:
            await msg.edit("🔄 𝗦𝘁𝗮𝗿𝘁𝗶𝗻𝗴 𝗟𝗶𝘃𝗲 𝗩𝗶𝗱𝗲𝗼 𝗦𝘁𝗿𝗲𝗮𝗺...")
            link = query
            thumb = "https://telegra.ph/file/3e14128ad5c9ec47801bd.jpg"

        vid_call = VIDEO_CALL.get(chat_id)
        if vid_call:
            await VIDEO_CALL[chat_id].stop()
            VIDEO_CALL.pop(chat_id)
            await sleep(3)

        aud_call = AUDIO_CALL.get(chat_id)
        if aud_call:
            await AUDIO_CALL[chat_id].stop()
            AUDIO_CALL.pop(chat_id)
            await sleep(3)

        try:
            await sleep(2)
            await group_call.join(chat_id)
            await group_call.start_video(link, with_audio=True, repeat=False)
            VIDEO_CALL[chat_id] = group_call
            await msg.delete()
            await m.reply_photo(
               photo=thumb, 
               caption=f"▶️ 𝗦𝘁𝗮𝗿𝘁𝗲𝗱 [Video Streaming]({query}) 𝗶𝗻 {m.chat.title} !",
               reply_markup=InlineKeyboardMarkup(
               [
                   [
                       InlineKeyboardButton(
                          text="⏸",
                          callback_data="pause_callback",
                       ),
                       InlineKeyboardButton(
                          text="▶️",
                          callback_data="resume_callback",
                       ),
                       InlineKeyboardButton(
                          text="⏹️",
                          callback_data="end_callback",
                       ),
                   ],
               ]),
            )
        except Exception as e:
            await msg.edit(f"❌ 𝗔𝗻 𝗘𝗿𝗿𝗼𝗿 𝗢𝗰𝗰𝗼𝘂𝗿𝗲𝗱 ! \n\n𝗘𝗿𝗿𝗼𝗿 : {e}")
            return await group_call.stop()

    elif media.video or media.document:
        await msg.edit("🔄 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱𝗶𝗻𝗴...")
        if media.video and media.video.thumbs:
            lol = media.video.thumbs[0]
            lel = await client.download_media(lol['file_id'])
            thumb = lel
        else:
            thumb = "https://telegra.ph/file/62e86d8aadde9a8cbf9c2.jpg"

        video = await client.download_media(media)

        vid_call = VIDEO_CALL.get(chat_id)
        if vid_call:
            await VIDEO_CALL[chat_id].stop()
            VIDEO_CALL.pop(chat_id)
            await sleep(3)

        aud_call = AUDIO_CALL.get(chat_id)
        if aud_call:
            await AUDIO_CALL[chat_id].stop()
            AUDIO_CALL.pop(chat_id)
            await sleep(3)

        try:
            await sleep(2)
            await group_call.join(chat_id)
            await group_call.start_video(video, with_audio=True, repeat=False)
            VIDEO_CALL[chat_id] = group_call
            await msg.delete()
            await m.reply_photo(
               photo=thumb,
               caption=f"▶️ 𝗦𝘁𝗮𝗿𝘁𝗲𝗱 [Video Streaming](https://t.me/Metiwz) 𝗶𝗻 {m.chat.title} !",
               reply_markup=InlineKeyboardMarkup(
               [
                   [
                       InlineKeyboardButton(
                          text="⏸",
                          callback_data="pause_callback",
                       ),
                       InlineKeyboardButton(
                          text="▶️",
                          callback_data="resume_callback",
                       ),
                       InlineKeyboardButton(
                          text="⏹️",
                          callback_data="end_callback",
                       ),
                   ],
               ]),
            )
        except Exception as e:
            await msg.edit(f"❌ 𝗔𝗻 𝗘𝗿𝗿𝗼𝗿 𝗢𝗰𝗰𝗼𝘂𝗿𝗲𝗱 ! \n\n𝗘𝗿𝗿𝗼𝗿 : {e}")
            return await group_call.stop()

    else:
        await msg.edit(
            "💁🏻‍♂️ 𝗗𝗼 𝗬𝗼𝘂 𝗪𝗮𝗻𝘁 𝗧𝗼 𝗦𝗲𝗮𝗿𝗰𝗵 𝗙𝗼𝗿 𝗔 𝗬𝗼𝘂𝘁𝘂𝗯𝗲 𝗩𝗶𝗱𝗲𝗼 ?",
            reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "✅ Yes", switch_inline_query_current_chat=""
                    ),
                    InlineKeyboardButton(
                        "No ❌", callback_data="close"
                    )
                ]
            ]
        )
    )


@Client.on_message(filters.command(["pause", f"pause@{USERNAME}"]) & filters.group & ~filters.edited)
@authorized_users_only
async def pause(_, m: Message):
    chat_id = m.chat.id

    if chat_id in AUDIO_CALL:
        await AUDIO_CALL[chat_id].set_audio_pause(True)
        await m.reply_text("⏸ 𝗣𝗮𝘂𝘀𝗲𝗱 𝗔𝘂𝗱𝗶𝗼 𝗦𝘁𝗿𝗲𝗮𝗺𝗶𝗻𝗴 !")

    elif chat_id in VIDEO_CALL:
        await VIDEO_CALL[chat_id].set_video_pause(True)
        await m.reply_text("⏸ 𝗣𝗮𝘂𝘀𝗲𝗱 𝗩𝗶𝗱𝗲𝗼 𝗦𝘁𝗿𝗲𝗮𝗺𝗶𝗻𝗴 !")

    else:
        await m.reply_text("❌ 𝗡𝗼𝘁𝗵𝗶𝗻𝗴 𝗶𝘀 𝗣𝗹𝗮𝘆𝗶𝗻𝗴 !")


@Client.on_message(filters.command(["resume", f"resume@{USERNAME}"]) & filters.group & ~filters.edited)
@authorized_users_only
async def resume(_, m: Message):
    chat_id = m.chat.id

    if chat_id in AUDIO_CALL:
        await AUDIO_CALL[chat_id].set_audio_pause(False)
        await m.reply_text("▶️ 𝗥𝗲𝘀𝘂𝗺𝗲𝗱 𝗔𝘂𝗱𝗶𝗼 𝗦𝘁𝗿𝗲𝗮𝗺𝗶𝗻𝗴 !")

    elif chat_id in VIDEO_CALL:
        await VIDEO_CALL[chat_id].set_video_pause(False)
        await m.reply_text("▶️ 𝗥𝗲𝘀𝘂𝗺𝗲𝗱 𝗩𝗶𝗱𝗲𝗼 𝗦𝘁𝗿𝗲𝗮𝗺𝗶𝗻𝗴 !")

    else:
        await m.reply_text("❌ 𝗡𝗼𝘁𝗵𝗶𝗻𝗴 𝗶𝘀 𝗦𝘁𝗿𝗲𝗮𝗺𝗶𝗻𝗴 !")


@Client.on_message(filters.command(["endstream", f"endstream@{USERNAME}"]) & filters.group & ~filters.edited)
@authorized_users_only
async def endstream(client, m: Message):
    msg = await m.reply_text("🔄 𝗣𝗿𝗼𝗰𝗲𝘀𝘀𝗶𝗻𝗴...")
    chat_id = m.chat.id

    if chat_id in AUDIO_CALL:
        await AUDIO_CALL[chat_id].stop()
        AUDIO_CALL.pop(chat_id)
        await msg.edit("⏹️ 𝗦𝘁𝗼𝗽𝗽𝗲𝗱 𝗔𝘂𝗱𝗶𝗼 𝗦𝘁𝗿𝗲𝗮𝗺𝗶𝗻𝗴 !")

    elif chat_id in VIDEO_CALL:
        await VIDEO_CALL[chat_id].stop()
        VIDEO_CALL.pop(chat_id)
        await msg.edit("⏹️ 𝗦𝘁𝗼𝗽𝗽𝗲𝗱 𝗩𝗶𝗱𝗲𝗼 𝗦𝘁𝗿𝗲𝗮𝗺𝗶𝗻𝗴 !")

    else:
        await msg.edit("🤖 𝗣𝗹𝗲𝗮𝘀𝗲 𝗦𝘁𝗮𝗿𝘁 𝗔𝗻 𝗦𝘁𝗿𝗲𝗮𝗺 𝗙𝗶𝗿𝘀𝘁 !")


# pytgcalls handlers

@group_call.on_audio_playout_ended
async def audio_ended_handler(_, __):
    await sleep(3)
    await group_call.stop()
    print(f"[INFO] - AUDIO_CALL ENDED !")

@group_call.on_video_playout_ended
async def video_ended_handler(_, __):
    await sleep(3)
    await group_call.stop()
    print(f"[INFO] - VIDEO_CALL ENDED !")
