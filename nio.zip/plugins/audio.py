import os
import re
import sys
import ffmpeg
import asyncio
import subprocess
from asyncio import sleep
from pyrogram import Client, filters
from pyrogram.types import Message
from helpers.bot_utils import USERNAME
from config import AUDIO_CALL, VIDEO_CALL
from plugins.video import ydl, group_call
from helpers.decorators import authorized_users_only, sudo_users_only
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery


@Client.on_message(filters.command(["play", f"play@{USERNAME}"]) & filters.group & ~filters.edited)
@authorized_users_only
async def play(client, m: Message):
    msg = await m.reply_text("🔄 𝗣𝗿𝗼𝗰𝗲𝘀𝘀𝗶𝗻𝗴...")
    chat_id = m.chat.id
    media = m.reply_to_message
    if not media and not ' ' in m.text:
        await msg.edit("❗𝗦𝗲𝗻𝗱 𝗠𝗲 𝗔𝗻 𝗟𝗶𝘃𝗲 𝗥𝗮𝗱𝗶𝗼 𝗟𝗶𝗻𝗸 / 𝗬𝗼𝘂𝘁𝘂𝗯𝗲 𝗩𝗶𝗱𝗲𝗼 𝗟𝗶𝗻𝗸 / 𝗥𝗲𝗽𝗹𝘆 𝗧𝗼 𝗔𝗻 𝗔𝘂𝗱𝗶𝗼 𝗧𝗼 𝗦𝘁𝗮𝗿𝘁 𝗔𝘂𝗱𝗶𝗼 𝗦𝘁𝗿𝗲𝗮𝗺𝗶𝗻𝗴 !")

    elif ' ' in m.text:
        text = m.text.split(' ', 1)
        query = text[1]
        if not 'http' in query:
            return await msg.edit("❗𝗦𝗲𝗻𝗱 𝗠𝗲 𝗔𝗻 𝗟𝗶𝘃𝗲 𝗥𝗮𝗱𝗶𝗼 𝗟𝗶𝗻𝗸 / 𝗬𝗼𝘂𝘁𝘂𝗯𝗲 𝗩𝗶𝗱𝗲𝗼 𝗟𝗶𝗻𝗸 / 𝗥𝗲𝗽𝗹𝘆 𝗧𝗼 𝗔𝗻 𝗔𝘂𝗱𝗶𝗼 𝗧𝗼 𝗦𝘁𝗮𝗿𝘁 𝗔𝘂𝗱𝗶𝗼 𝗦𝘁𝗿𝗲𝗮𝗺𝗶𝗻𝗴 !")
        regex = r"^(https?\:\/\/)?(www\.youtube\.com|youtu\.?be)\/.+"
        match = re.match(regex, query)
        if match:
            await msg.edit("🔄 𝗦𝘁𝗮𝗿𝘁𝗶𝗻𝗴 𝗬𝗼𝘂𝘁𝘂𝗯𝗲 𝗔𝘂𝗱𝗶𝗼 𝗦𝘁𝗿𝗲𝗮𝗺...")
            try:
                meta = ydl.extract_info(query, download=False)
                formats = meta.get('formats', [meta])
                for f in formats:
                    ytstreamlink = f['url']
                link = ytstreamlink
            except Exception as e:
                return await msg.edit(f"❌ 𝗬𝗼𝘂𝘁𝘂𝗯𝗲 𝗗𝗮𝘄𝗻𝗹𝗼𝗮𝗱 𝗘𝗿𝗿𝗼𝗿 !\n\n{e}")
                print(e)

        else:
            await msg.edit("🔄 𝗦𝘁𝗮𝗿𝘁𝗶𝗻𝗴 𝗟𝗶𝘃𝗲 𝗔𝘂𝗱𝗶𝗼 𝗦𝘁𝗿𝗲𝗮𝗺...")
            link = query

        vid_call = VIDEO_CALL.get(chat_id)
        if vid_call:
            await VIDEO_CALL[chat_id].stop()
            VIDEO_CALL.pop(chat_id)
            await sleep(3)

        aud_call = AUDIO_CALL.get(chat_id)
        if aud_call:
            await AUDIO_CALL[chat_id].stop()
            AUDIO_CALL.pop(chat_id)
            await sleep(3)

        try:
            await sleep(2)
            await group_call.join(chat_id)
            await group_call.start_audio(link, repeat=False)
            AUDIO_CALL[chat_id] = group_call
            await msg.delete()
            await m.reply_text(f"▶️ 𝗦𝘁𝗮𝗿𝘁𝗲𝗱 [Audio Streaming]({query}) 𝗶𝗻 {m.chat.title} !",
               reply_markup=InlineKeyboardMarkup(
               [
                   [
                       InlineKeyboardButton(
                          text="⏸",
                          callback_data="pause_callback",
                       ),
                       InlineKeyboardButton(
                          text="▶️",
                          callback_data="resume_callback",
                       ),
                       InlineKeyboardButton(
                          text="⏹️",
                          callback_data="end_callback",
                       ),
                   ],
               ]),
            )
        except Exception as e:
            await msg.edit(f"❌ 𝗔𝗻 𝗘𝗿𝗿𝗼𝗿 𝗢𝗰𝗰𝗼𝘂𝗿𝗲𝗱 ! \n\n𝗘𝗿𝗿𝗼𝗿 : {e}")
            return await group_call.stop()

    elif media.audio or media.document:
        await msg.edit("🔄 𝗗𝗼𝘄𝗻𝗹𝗼𝗱𝗶𝗻𝗴...")
        audio = await client.download_media(media)

        vid_call = VIDEO_CALL.get(chat_id)
        if vid_call:
            await VIDEO_CALL[chat_id].stop()
            VIDEO_CALL.pop(chat_id)
            await sleep(3)

        aud_call = AUDIO_CALL.get(chat_id)
        if aud_call:
            await AUDIO_CALL[chat_id].stop()
            AUDIO_CALL.pop(chat_id)
            await sleep(3)

        try:
            await sleep(2)
            await group_call.join(chat_id)
            await group_call.start_audio(audio, repeat=False)
            AUDIO_CALL[chat_id] = group_call
            await msg.delete()
            await m.reply_text(f"▶️ 𝗦𝘁𝗮𝗿𝘁𝗲𝗱 [Audio Streaming](https://t.me/Metiwz) 𝗶𝗻 {m.chat.title} !**",
               reply_markup=InlineKeyboardMarkup(
               [
                   [
                       InlineKeyboardButton(
                          text="⏸",
                          callback_data="pause_callback",
                       ),
                       InlineKeyboardButton(
                          text="▶️",
                          callback_data="resume_callback",
                       ),
                       InlineKeyboardButton(
                          text="⏹️",
                          callback_data="end_callback",
                       ),
                   ],
               ]),
            )
        except Exception as e:
            await msg.edit(f"❌ 𝗔𝗻 𝗘𝗿𝗿𝗼𝗿 𝗢𝗰𝗰𝗼𝘂𝗿𝗲𝗱 ! \n\n𝗘𝗿𝗿𝗼𝗿 : {e}")
            return await group_call.stop()

    else:
        await msg.edit(
            "💁🏻‍♂️ 𝗗𝗼 𝗬𝗼𝘂 𝗪𝗮𝗻𝘁 𝗧𝗼 𝗦𝗲𝗮𝗿𝗰𝗵 𝗙𝗼𝗿 𝗔 𝗬𝗼𝘂𝘁𝘂𝗯𝗲 𝗦𝗼𝗻𝗴 ?",
            reply_markup=InlineKeyboardMarkup(
            [
                [
                    InlineKeyboardButton(
                        "✅ 𝗬𝗲𝘀", switch_inline_query_current_chat=""
                    ),
                    InlineKeyboardButton(
                        "𝗡𝗼 ❌", callback_data="close"
                    )
                ]
            ]
        )
    )


@Client.on_message(filters.command(["restart", f"restart@{USERNAME}"]))
@sudo_users_only
async def restart(client, m: Message):
    k = await m.reply_text("🔄 𝗥𝗲𝘀𝘁𝗮𝗿𝘁𝗶𝗻𝗴 ...")
    await sleep(3)
    os.execl(sys.executable, sys.executable, *sys.argv)
    try:
        await k.edit("✅ 𝗥𝗲𝘀𝘁𝗮𝗿𝘁𝗲𝗱 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆 !")
    except:
        pass
